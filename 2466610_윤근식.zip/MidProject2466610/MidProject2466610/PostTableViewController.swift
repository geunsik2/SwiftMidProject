//
//  PostTableViewController.swift
//  MidProject2466610
//
//  Created by 세근식 on 10/24/24.
//

import UIKit
import Alamofire

class PostTableViewController: UITableViewController {
    
    var posts : [Post]? = []

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchPosts()
    }
    
    func fetchPosts() {
        let urlString = "https://jsonplaceholder.typicode.com/posts"
        
        let url = URL(string: urlString)
        AF.request(url!, method: .get).responseDecodable(of: PostResponse.self) { response in
            if let postResponse = response.value {
                // 성공적으로 데이터를 받아왔을 때
                print(postResponse)
                
                DispatchQueue.main.async {
                    // poiList에 Poi 객체 리스트로 저장
                    self.posts = postResponse
                    
                    // 테이블 뷰를 리로드
                    self.tableView.reloadData()
                }
            } else if let error = response.error {
                // 요청이 실패했을 때
                print(error)
            }
        }
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return posts?.count ?? 0
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PostTableViewCell", for: indexPath) as! PostTableViewCell
        
        if let post = self.posts?[indexPath.row] {
            cell.titleLabel.text = post.title
            cell.contentLabel.text = post.body
        }

        return cell
    }
}
