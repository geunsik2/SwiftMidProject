//
//  ViewController.swift
//  MidProject2466610
//
//  Created by 세근식 on 10/24/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

