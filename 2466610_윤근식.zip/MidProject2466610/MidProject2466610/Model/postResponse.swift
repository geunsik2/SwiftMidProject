//
//  postResponse.swift
//  MidProject2466610
//
//  Created by 세근식 on 10/24/24.
//

import Foundation

struct Post: Codable {
let id: Int
let title, body: String
}

typealias PostResponse = [Post]
