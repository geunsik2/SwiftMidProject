//
//  MidProject2466610Tests.swift
//  MidProject2466610Tests
//
//  Created by 세근식 on 10/24/24.
//

import Testing
@testable import MidProject2466610

struct MidProject2466610Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
